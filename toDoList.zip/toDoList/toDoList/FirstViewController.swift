//
//  FirstViewController.swift
//  toDoList
//
//  Created by Bharath Gandham on 10/1/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit
var list = ["Hai","Hello","bye","good bye"]
class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var btnEditOutlet: UIBarButtonItem!
    @IBOutlet weak var tableViewForToDoList: UITableView!
    /*func tableView(_ tableView: UITableView, titleForHeaderInSection section:Int) -> String?
    {
        return "ToDo List"
    }*/
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return (list.count)
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "toDoListProtoTypeCell")
        cell?.textLabel?.text = list[indexPath.row]
        //cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator
        return cell!
    }
    //Reordering of cells
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt SourceIndexPath:IndexPath, to destinationIndexPath:IndexPath)
    {
        let item = list[SourceIndexPath.row]
        list.remove(at: SourceIndexPath.row)
        list.insert(item, at: destinationIndexPath.row)
    }
    //Deleting a cell
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == UITableViewCell.EditingStyle.delete
        {
            list.remove(at: indexPath.row)
            tableViewForToDoList.reloadData()
        }
    }
    //editing content
   /* func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let editButton = UITableViewRowAction(style: .normal, title: "something"){
            (rowAction,IndexPath) in
        }
    }*/
    override func viewDidAppear(_ animated: Bool) {
        tableViewForToDoList.reloadData()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //Edit button actions
    @IBAction func btnEdit(_ sender: Any) {
        tableViewForToDoList.isEditing = !tableViewForToDoList.isEditing
        switch tableViewForToDoList.isEditing {
        case true:
            btnEditOutlet.title="Done"
        case false:
            btnEditOutlet.title="Edit"
        }
    }
    
}

