//
//  SecondViewController.swift
//  toDoList
//
//  Created by Bharath Gandham on 10/1/19.
//  Copyright © 2019 Bharath Gandham. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var txtAddItemToDoList: UITextField!
    
    @IBOutlet weak var lblToThrowFlashMessages: UILabel!
    @IBOutlet weak var btnAddItemToDoList: UIButton!
    func showToast(controller: UIViewController, message : String, seconds: Double) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.view.backgroundColor = UIColor.black
        alert.view.alpha = 0.6
        alert.view.layer.cornerRadius = 15

        controller.present(alert, animated: true)

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            alert.dismiss(animated: true)
        }
    }

    @IBAction func btnAddItemToDoList(_ sender: Any) {
        if(txtAddItemToDoList.text != "")
        {
        list.append(txtAddItemToDoList.text!)
            txtAddItemToDoList.text=""
            /*lblToThrowFlashMessages.isHidden = false
            lblToThrowFlashMessages.text="Added Successfully"
            UIView.animate(withDuration: 1, animations: { () -> Void in
                self.lblToThrowFlashMessages.alpha = 0})*/
            showToast(controller: self, message : "Added Successfully", seconds: 0.5)
        }
       else{
            /*lblToThrowFlashMessages.isHidden = false
            lblToThrowFlashMessages.text="Type something to add"
            UIView.animate(withDuration: 1, animations: { () -> Void in
                self.lblToThrowFlashMessages.alpha = 0})*/
            showToast(controller: self, message : "Failed! Enter something to add", seconds: 0.5)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        txtAddItemToDoList.becomeFirstResponder()
    }

    @IBAction func keyBoardScrollingDownUponPressingReturn(_ sender: UITextField) {
        txtAddItemToDoList.resignFirstResponder()
    }
    
}

